# Solana Memecoin Toolkit 🐕

A simple open-source command-line tool for searching and running basic checks on **Solana** meme coins.

> ⚠️ **Disclaimer:** This project is for educational purposes only and is not financial advice. Most meme coins are extremely high-risk, and many are scams (rug pulls). No tool can guarantee that a token is safe.

## Features

- Search Solana tokens by name or symbol (via the DexScreener API)
- Filter results by minimum liquidity
- On-chain red-flag checks:
  - Is the **mint authority** revoked? (ability to create more supply)
  - Is the **freeze authority** set? (ability to freeze token accounts)
  - Share of total supply held by the top 10 accounts
  - Very low liquidity and very young trading pairs

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/solana-memecoin-toolkit.git
cd solana-memecoin-toolkit
pip install -r requirements.txt
```

## Usage

```bash
# Search for tokens
python main.py search bonk --limit 5 --min-liquidity 50000

# Check a token by its mint address
python main.py check <MINT_ADDRESS>
```

For better reliability, you can use your own RPC endpoint. The default is the public Solana RPC, which is rate-limited:

```bash
export SOLANA_RPC_URL="https://your-rpc-provider.example"
```

## Project Structure

```
├── main.py              # Command-line interface
├── src/
│   ├── dexscreener.py   # Market data client
│   └── risk_check.py    # On-chain checks
├── requirements.txt
└── LICENSE
```

## Limitations

- The top-10 share includes liquidity pool and burn accounts, so interpret it with care.
- "No warnings" does not mean "safe". The checks are heuristics only.
- Price and liquidity data come from DexScreener and may be delayed.

## Ideas for Future Work

- List newly created tokens (token profiles)
- Check token metadata and social links
- JSON/CSV output
- Unit tests for `evaluate_flags`

## Contributing

Issues and pull requests are welcome.

## License

MIT
