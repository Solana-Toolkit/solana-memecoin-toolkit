"""Basic on-chain red-flag checks for a Solana token.

These checks are heuristics. A clean result does NOT mean a token is safe.
"""
import os
import time

import requests

RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
TIMEOUT = 15


def _rpc(method, params):
    r = requests.post(
        RPC_URL,
        json={"jsonrpc": "2.0", "id": 1, "method": method, "params": params},
        timeout=TIMEOUT,
    )
    r.raise_for_status()
    body = r.json()
    if "error" in body:
        raise RuntimeError(body["error"])
    return body["result"]


def get_mint_info(mint):
    """Parsed SPL mint account: authorities, supply, decimals."""
    value = _rpc("getAccountInfo", [mint, {"encoding": "jsonParsed"}]).get("value")
    if not value:
        raise ValueError("Mint account not found")
    data = value.get("data")
    parsed = data.get("parsed") if isinstance(data, dict) else None
    if not parsed or parsed.get("type") != "mint":
        raise ValueError("Address is not a token mint")
    return parsed["info"]


def top10_share(mint, supply_raw):
    """Share (0-100) of supply held by the 10 largest token accounts.

    Note: this includes liquidity-pool and burn accounts, so read it with care.
    """
    accounts = _rpc("getTokenLargestAccounts", [mint])["value"][:10]
    total = int(supply_raw)
    if total == 0:
        return 0.0
    return sum(int(a["amount"]) for a in accounts) / total * 100


def evaluate_flags(mint_info, top10_pct=None, pair=None, now=None):
    """Turn raw data into a list of human-readable warnings."""
    flags = []
    if mint_info.get("mintAuthority"):
        flags.append("Mint authority is NOT revoked: more supply can be minted.")
    if mint_info.get("freezeAuthority"):
        flags.append("Freeze authority is set: token accounts can be frozen.")
    if top10_pct is not None and top10_pct > 40:
        flags.append(f"Top 10 accounts hold {top10_pct:.1f}% of supply.")
    if pair:
        liq = (pair.get("liquidity") or {}).get("usd") or 0
        if liq < 10_000:
            flags.append(f"Very low liquidity (${liq:,.0f}).")
        created = pair.get("pairCreatedAt")
        if created:
            age_h = ((now or time.time()) - created / 1000) / 3600
            if age_h < 24:
                flags.append(f"Pair is only {age_h:.1f} hours old.")
    else:
        flags.append("No trading pair found on DexScreener.")
    return flags


def analyze_mint(mint, pair=None):
    info = get_mint_info(mint)
    try:
        top10 = top10_share(mint, info["supply"])
    except Exception:  # public RPCs sometimes rate-limit this call
        top10 = None
    return {
        "mint": mint,
        "supply": int(info["supply"]) / 10 ** info["decimals"],
        "mint_authority": info.get("mintAuthority"),
        "freeze_authority": info.get("freezeAuthority"),
        "top10_pct": top10,
        "flags": evaluate_flags(info, top10, pair),
    }
