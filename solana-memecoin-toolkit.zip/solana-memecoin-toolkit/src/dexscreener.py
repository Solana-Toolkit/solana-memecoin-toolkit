"""Thin client for the public DexScreener API (Solana pairs only)."""
import requests

BASE = "https://api.dexscreener.com"
TIMEOUT = 15


def _liq(pair):
    return (pair.get("liquidity") or {}).get("usd") or 0


def search_solana_pairs(query):
    """Search pairs by name/symbol/address and keep only Solana ones."""
    r = requests.get(f"{BASE}/latest/dex/search", params={"q": query}, timeout=TIMEOUT)
    r.raise_for_status()
    pairs = r.json().get("pairs") or []
    return [p for p in pairs if p.get("chainId") == "solana"]


def get_token_pairs(mint):
    """All Solana pairs for a token mint address."""
    r = requests.get(f"{BASE}/tokens/v1/solana/{mint}", timeout=TIMEOUT)
    r.raise_for_status()
    data = r.json()
    return data if isinstance(data, list) else []


def best_pair(pairs):
    """The pair with the deepest liquidity, or None."""
    return max(pairs, key=_liq, default=None)
