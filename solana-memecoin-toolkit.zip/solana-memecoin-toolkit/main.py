"""Solana meme coin toolkit: search tokens and run basic red-flag checks."""
import argparse
import sys

from src.dexscreener import best_pair, get_token_pairs, search_solana_pairs
from src.risk_check import analyze_mint


def usd(n):
    if n is None:
        return "-"
    for unit, div in (("B", 1e9), ("M", 1e6), ("K", 1e3)):
        if abs(n) >= div:
            return f"${n / div:.2f}{unit}"
    return f"${n:,.4f}" if abs(n) < 1 else f"${n:,.2f}"


def cmd_search(args):
    pairs = search_solana_pairs(args.query)
    pairs.sort(key=lambda p: (p.get("liquidity") or {}).get("usd") or 0, reverse=True)
    seen, shown = set(), 0
    for p in pairs:
        mint = p["baseToken"]["address"]
        liq = (p.get("liquidity") or {}).get("usd") or 0
        if mint in seen or liq < args.min_liquidity:
            continue
        seen.add(mint)
        chg = (p.get("priceChange") or {}).get("h24")
        print(
            f"{p['baseToken']['symbol']:<10} price {usd(float(p.get('priceUsd') or 0)):<12} "
            f"liq {usd(liq):<10} vol24h {usd((p.get('volume') or {}).get('h24')):<10} "
            f"24h {chg if chg is not None else '-'}%\n  {mint}"
        )
        shown += 1
        if shown >= args.limit:
            break
    if not shown:
        print("No results. Try a different query or lower --min-liquidity.")


def cmd_check(args):
    pair = best_pair(get_token_pairs(args.mint))
    result = analyze_mint(args.mint, pair)
    print(f"Mint:             {result['mint']}")
    print(f"Supply:           {result['supply']:,.0f}")
    print(f"Mint authority:   {result['mint_authority'] or 'revoked'}")
    print(f"Freeze authority: {result['freeze_authority'] or 'revoked'}")
    if result["top10_pct"] is not None:
        print(f"Top 10 holders:   {result['top10_pct']:.1f}%")
    print()
    if result["flags"]:
        print("Warnings:")
        for f in result["flags"]:
            print(f"  - {f}")
    else:
        print("No basic red flags found (this does not mean the token is safe).")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search", help="search Solana tokens by name or symbol")
    s.add_argument("query")
    s.add_argument("--limit", type=int, default=10)
    s.add_argument("--min-liquidity", type=float, default=10_000)
    s.set_defaults(func=cmd_search)

    c = sub.add_parser("check", help="red-flag check for a token mint address")
    c.add_argument("mint")
    c.set_defaults(func=cmd_check)

    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
